#include <stdio.h>
#include <stdlib.h>


int		main(void)
{
	int k, n;
	scanf("%d %d", &k, &n);
	
	int *mn  = (int *)malloc(sizeof(int) * n);

	mn[0] = 1;

	for (int i = 0; i < n; i++)
	{
		int j = i - 1;
		int sum = 0;
		while (j >= 0 && j >= i - k)
		{
			printf("%d--%d\n", j, mn[j]);
			sum += mn[j];
			j--;
		}
		j = 0;
		printf("-----%d------\n", sum);
		if (sum != 0)
			mn[i] = sum;
	}

	printf("%d\n", mn[n - 1]);
	return (0);
}
